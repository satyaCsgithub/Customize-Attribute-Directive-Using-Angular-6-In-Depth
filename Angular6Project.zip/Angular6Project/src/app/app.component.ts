import { Component } from '@angular/core';

@Component({
   selector: 'Satya-App',
   templateUrl: './app.component.html'
})
export class AppComponent { 
   txtsize = '25px';
   colors = ['CYAN', 'GREEN', 'YELLOW'];
   myColor = '';
}