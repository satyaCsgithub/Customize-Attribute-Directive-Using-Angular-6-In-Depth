import { Directive, ElementRef, Input, AfterViewInit } from '@angular/core';

@Directive({ 
     selector: '[MytextSize]' 
})
export class TextSizeDirective implements AfterViewInit{
    @Input('MytextSize') tsize: string;
    constructor(private elRef: ElementRef) { 
    }
    ngAfterViewInit(): void {
	this.elRef.nativeElement.style.fontSize = this.tsize;
    }
} 