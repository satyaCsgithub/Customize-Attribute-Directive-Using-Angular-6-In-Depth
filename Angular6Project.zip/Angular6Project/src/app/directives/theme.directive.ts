import { Directive, ElementRef } from '@angular/core';

@Directive({ 
     selector: '[satyaTheme]' 
})
export class satyaThemeDirective {
    constructor(elRef: ElementRef) {
       elRef.nativeElement.style.color = 'blue';
       elRef.nativeElement.style.backgroundColor = 'yellow';
       elRef.nativeElement.style.fontSize = '70px';
    }
} 