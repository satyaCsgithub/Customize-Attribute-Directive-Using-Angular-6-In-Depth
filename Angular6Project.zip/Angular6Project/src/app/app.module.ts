import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { MyRedDirective }  from './directives/red.directive';
import { satyaThemeDirective }  from './directives/theme.directive';
import { ColorInputDirective }  from './directives/color-input.directive';
import { TextSizeDirective }  from './directives/text-size.directive';
import { CustomThemeDirective }  from './directives/custom-theme.directive';
import { MouseActionDirective }  from './directives/mouse.directive';
import { DynamicColorDirective }  from './directives/dynamic-color.directive';

@NgModule({
  declarations: [
    AppComponent,
    MyRedDirective,
    satyaThemeDirective,
    ColorInputDirective,
    TextSizeDirective,
    CustomThemeDirective,
    MouseActionDirective,
    DynamicColorDirective
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
